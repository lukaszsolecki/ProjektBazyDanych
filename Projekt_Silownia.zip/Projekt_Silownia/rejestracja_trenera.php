<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $imie = $_POST['imie'];
    $nazwisko = $_POST['nazwisko'];
    $specjalizacja = $_POST['specjalizacja'];
    $doswiadczenie = $_POST['doswiadczenie'];
    $telefon = $_POST['telefon'];
    $email = $_POST['email'];
    $haslo = $_POST['haslo'];

    $result = registerTrener($imie, $nazwisko, $specjalizacja, $doswiadczenie, $telefon, $email, $haslo);
    if ($result === true) {
        header("Location: trainer_dashboard.php");
        exit();
    } else {
        echo "<script>alert('Podany email ($email) już istnieje w bazie danych.');</script>";
    }
}

function registerTrener($imie, $nazwisko, $specjalizacja, $doswiadczenie, $telefon, $email, $haslo)
{
    $conn = getConnection();
    $checkEmailQuery = "SELECT COUNT(*) FROM TRENERZY WHERE EMAIL = :email";
    $stid = oci_parse($conn, $checkEmailQuery);
    oci_bind_by_name($stid, ':email', $email);
    oci_execute($stid);
    $row = oci_fetch_array($stid, OCI_ASSOC);
    oci_free_statement($stid);

    if ($row['COUNT(*)'] > 0) {
        oci_close($conn);
        return false;
    }

    $conn = getConnection();
    $query = "BEGIN TRAINER_FUNCTIONS.RegisterTrener(:imie, :nazwisko, :specjalizacja, :doswiadczenie, :telefon, :email, :haslo); END;";
    $stid = oci_parse($conn, $query);
    oci_bind_by_name($stid, ':imie', $imie);
    oci_bind_by_name($stid, ':nazwisko', $nazwisko);
    oci_bind_by_name($stid, ':specjalizacja', $specjalizacja);
    oci_bind_by_name($stid, ':doswiadczenie', $doswiadczenie);
    oci_bind_by_name($stid, ':telefon', $telefon);
    oci_bind_by_name($stid, ':email', $email);
    oci_bind_by_name($stid, ':haslo', $haslo);

    oci_execute($stid);
    oci_free_statement($stid);
    oci_close($conn);

    return true;
}

?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta http-equiv="Content-Language" content="pl">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestracja - Trenera</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="trainer_dashboard.php">Witaj, <?php echo $_SESSION['login']; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="trainer_dashboard.php#utwurz_zajecia">Utwórz zajęcia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="trainer_dashboard.php#opinie">Sprawdź opinie</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="trainer_dashboard.php#analiza">Analizy składu ciała</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rejestracja_trenera.php">Zarejestruj trenera</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Wyloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5">
                    <div class="card-header">
                        <h3>Rejestracja trenera</h3>
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="imie" class="form-label">Imię</label>
                                <input type="text" class="form-control" id="imie" name="imie" required>
                            </div>
                            <div class="mb-3">
                                <label for="nazwisko" class="form-label">Nazwisko</label>
                                <input type="text" class="form-control" id="nazwisko" name="nazwisko" required>
                            </div>
                            <div class="mb-3">
                                <label for="specjalizacja" class="form-label">Specjalizacja</label>
                                <input type="text" class="form-control" id="specjalizacja" name="specjalizacja" required>
                            </div>
                            <div class="mb-3">
                                <label for="doswiadczenie" class="form-label">Doświadczenie</label>
                                <input type="number" class="form-control" id="doswiadczenie" name="doswiadczenie" required>
                            </div>
                            <div class="mb-3">
                                <label for="telefon" class="form-label">Telefon</label>
                                <input type="tel" class="form-control" id="telefon" name="telefon" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="haslo" class="form-label">Hasło</label>
                                <input type="password" class="form-control" id="haslo" name="haslo" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Zarejestruj trenera</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>