<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'client') {
    header("Location: login.php");
    exit();
}

include 'connection.php';
$conn = getConnection();
$login = $_SESSION['login'];

$query = "BEGIN :result := KLIENT_FUNCTIONS.get_client_data(:p_email); END;";
$statement = oci_parse($conn, $query);
$result_cursor = oci_new_cursor($conn);
oci_bind_by_name($statement, ':result', $result_cursor, -1, OCI_B_CURSOR);
oci_bind_by_name($statement, ':p_email', $login);
oci_execute($statement);
oci_execute($result_cursor);
$clientData = oci_fetch_assoc($result_cursor);
oci_free_statement($statement);

$queryMeasurements = "BEGIN KLIENT_FUNCTIONS.POMIARYSKLADUCIALA(:p_login, :p_pomiary); END;";
$statementMeasurements = oci_parse($conn, $queryMeasurements);
$cursor = oci_new_cursor($conn);
oci_bind_by_name($statementMeasurements, ':p_login', $login);
oci_bind_by_name($statementMeasurements, ':p_pomiary', $cursor, -1, OCI_B_CURSOR);
oci_execute($statementMeasurements);
oci_execute($cursor);

$bodyMeasurements = array();
while (($row = oci_fetch_assoc($cursor)) != false) {
    $bodyMeasurements[] = $row;
}
oci_free_statement($statementMeasurements);

$measurements = [];
if (isset($_GET['id_klienta'])) {
    $clientId = $_GET['id_klienta'];
    echo "Identyfikator klienta: " . $clientId . "<br>";
    $query = "SELECT DATA, WAGA, WZROST, MASA_MIESNIOWA, TKANKA_TLUSZCZOWA
              FROM SILOWNIA.POMIARY_SKLADU_CIALA
              WHERE ID_KLIENTA = :id_klienta
              ORDER BY DATA DESC";
    $stid = oci_parse($conn, $query);
    oci_bind_by_name($stid, ':id_klienta', $clientId);
    oci_execute($stid);
    while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
        var_dump($row);
        $measurements[] = $row;
    }
    oci_free_statement($stid);
}


if (isset($_SESSION['karnet_message'])) {
    echo '<div class="alert alert-success" role="alert">' . $_SESSION['karnet_message'] . '</div>';
    unset($_SESSION['karnet_message']);
}

$queryZajecia = "BEGIN KLIENT_FUNCTIONS.POBIERZ_ZAJECIA_KLIENTA(:p_cursor, :p_login); END;";
$statementZajecia = oci_parse($conn, $queryZajecia);
$cursor = oci_new_cursor($conn);
oci_bind_by_name($statementZajecia, ':p_cursor', $cursor, -1, OCI_B_CURSOR);
oci_bind_by_name($statementZajecia, ':p_login', $login);
oci_execute($statementZajecia);
oci_execute($cursor);

$clientClasses = array();
while (($row = oci_fetch_assoc($cursor)) != false) {
    $clientClasses[] = $row;
}
oci_free_statement($statementZajecia);


if (isset($_POST['unenroll']) && isset($_POST['class_id'])) {
    $classId = intval($_POST['class_id']);

    $queryGetClientId = "SELECT ID_KLIENTA FROM KLIENCI WHERE EMAIL = :p_login";
    $statementGetClientId = oci_parse($conn, $queryGetClientId);
    oci_bind_by_name($statementGetClientId, ':p_login', $login);
    if (!oci_execute($statementGetClientId)) {
        $e = oci_error($statementGetClientId);
        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
    }
    $clientId = oci_fetch_array($statementGetClientId, OCI_BOTH)[0];
    oci_free_statement($statementGetClientId);

    $queryUnenroll = "BEGIN KLIENT_FUNCTIONS.WYPISZ_Z_ZAJEC(:p_id_klienta, :p_class_id); END;";
    $statementUnenroll = oci_parse($conn, $queryUnenroll);
    oci_bind_by_name($statementUnenroll, ':p_id_klienta', $clientId);
    oci_bind_by_name($statementUnenroll, ':p_class_id', $classId);
    if (!oci_execute($statementUnenroll)) {
        $e = oci_error($statementUnenroll);
        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
    }
    oci_free_statement($statementUnenroll);

    header("Location: client_dashboard.php");
    exit();
}


oci_close($conn);
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Klienta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .section-header {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }

        .accordion-button {
            background-color: #e9ecef;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Witaj, <?php echo $_SESSION['login']; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="zapis_na_zajecia.php">Zapisz się na zajęcia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="wystaw_opinie.php">Wystaw opinię</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kup_karnet.php">Aktualizuj karnet</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="opinie.php">Zobacz opinie</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Wyloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4">Witaj!</h1>
        <?php
        if (isset($_GET['error'])) {
            echo "<div class='alert alert-danger' role='alert'>";
            echo $_GET['error'];
            echo "</div>";
        }
        ?>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Moje dane:</h3>
                <p class="card-text"><strong>Imię:</strong> <?php echo $clientData['IMIE']; ?></p>
                <p class="card-text"><strong>Nazwisko:</strong> <?php echo $clientData['NAZWISKO']; ?></p>
                <p class="card-text"><strong>Adres:</strong> <?php echo $clientData['ADRES']; ?></p>
                <p class="card-text"><strong>Telefon:</strong> <?php echo $clientData['TELEFON']; ?></p>
                <p class="card-text"><strong>Email:</strong> <?php echo $clientData['EMAIL']; ?></p>
                <p class="card-text"><strong>Data urodzenia:</strong>
                    <?php
                    $date_of_birth = DateTime::createFromFormat('d-M-y', $clientData['DATA_URODZENIA']);
                    if ($date_of_birth) {
                        echo $date_of_birth->format('d-m-Y');
                    } else {
                        echo "Błąd parsowania daty urodzenia";
                    }
                    ?>
                </p>
                <p class="card-text"><strong>Status karnetu:</strong> <?php echo ($clientData['AKTYWNY']  == 'T') ? 'Aktywny' : 'Nieaktywny'; ?></p>
                <a href="client_edit_data.php" class="btn btn-primary">Edytuj</a>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <div class="accordion" id="accordionHistory">
                    <h3>Moje pomiary składu ciała</h3>
                    <?php if (empty($bodyMeasurements)) : ?>
                        <p>Brak danych</p>
                    <?php else : ?>
                        <?php foreach ($bodyMeasurements as $index => $measurement) : ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo $index; ?>">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $index; ?>" aria-expanded="true" aria-controls="collapse<?php echo $index; ?>">
                                        Pomiar z <?php
                                                    $measurement_date = DateTime::createFromFormat('d-M-y', $measurement['DATA']);
                                                    if ($measurement_date) {
                                                        echo $measurement_date->format('d-m-Y');
                                                    } else {
                                                        echo "Błąd parsowania daty pomiaru";
                                                    }
                                                    ?>
                                    </button>
                                </h2>
                                <div id="collapse<?php echo $index; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo $index; ?>" data-bs-parent="#accordionHistory">
                                    <div class="accordion-body">
                                        <p><strong>Waga:</strong> <?php echo $measurement['WAGA']; ?> kg</p>
                                        <p><strong>Wzrost:</strong> <?php echo $measurement['WZROST']; ?> cm</p>
                                        <p><strong>Masa mięśniowa:</strong> <?php echo $measurement['MASA_MIESNIOWA']; ?> kg</p>
                                        <p><strong>Tkanka tłuszczowa:</strong> <?php echo $measurement['TKANKA_TLUSZCZOWA']; ?>%</p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div><br><br>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Moje zajęcia:</h3>
                <?php if (empty($clientClasses)) : ?>
                    <p>Brak danych</p>
                <?php else : ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Nazwa zajęć</th>
                                <th scope="col">Trener</th>
                                <th scope="col">Siłownia</th>
                                <th scope="col">Data i godzina</th>
                                <th scope="col">Akcja</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($clientClasses as $class) : ?>
                                <tr>
                                    <td><?php echo $class['NAZWA_ZAJEC']; ?></td>
                                    <td><?php echo $class['TRENER']; ?></td>
                                    <td><?php echo $class['SILOWNIA']; ?></td>
                                    <td>
                                        <?php
                                        $date_time = DateTime::createFromFormat('d-M-y h.i.s.u A', $class['DATA_I_GODZINA']);
                                        if ($date_time) {
                                            echo $date_time->format('d-m-Y H:i');
                                        } else {
                                            echo "Błąd parsowania daty i godziny";
                                        }
                                        ?>
                                    </td>

                                    <td>
                                        <?php if (date_create_from_format('d-M-y h.i.s.u A', $class['DATA_I_GODZINA']) > new DateTime()) : ?>
                                            <form method="post" action="">
                                                <input type="hidden" name="class_id" value="<?php echo $class['ID_PROWADZENIA']; ?>">
                                                <button type="submit" name="unenroll" class="btn btn-danger btn-sm">Wypisz się</button>
                                            </form>
                                        <?php else : ?>
                                            Niedostępne
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

    </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>