<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}

include 'connection.php';
$conn = getConnection();
$login = $_SESSION['login'];

$query = 'BEGIN TRAINER_FUNCTIONS.POBIERZ_DANE_TRENERA(:cursor, :login); END;';
$stid = oci_parse($conn, $query);
$cursor = oci_new_cursor($conn);
oci_bind_by_name($stid, ':cursor', $cursor, -1, OCI_B_CURSOR);
oci_bind_by_name($stid, ':login', $login);
oci_execute($stid);
oci_execute($cursor, OCI_DEFAULT);
$trainerData = oci_fetch_array($cursor, OCI_ASSOC + OCI_RETURN_NULLS);

$query = 'BEGIN TRAINER_FUNCTIONS.POBIERZ_ZAJECIA_TRENERA(:cursor, :id_trenera); END;';
$stid = oci_parse($conn, $query);
$cursor = oci_new_cursor($conn);
oci_bind_by_name($stid, ':cursor', $cursor, -1, OCI_B_CURSOR);
oci_bind_by_name($stid, ':id_trenera', $trainerData['ID_TRENERA']);
oci_execute($stid);
oci_execute($cursor, OCI_DEFAULT);

$trainerClasses = [];
while ($row = oci_fetch_array($cursor, OCI_ASSOC + OCI_RETURN_NULLS)) {
    $trainerClasses[] = $row;
}

$query = 'BEGIN TRAINER_FUNCTIONS.POBIERZ_OPINIE_TRENERA(:cursor, :id_trenera); END;';
$stid = oci_parse($conn, $query);
$cursor = oci_new_cursor($conn);
oci_bind_by_name($stid, ':cursor', $cursor, -1, OCI_B_CURSOR);
oci_bind_by_name($stid, ':id_trenera', $trainerData['ID_TRENERA']);
oci_execute($stid);
oci_execute($cursor, OCI_DEFAULT);

$trainerReviews = [];
while ($row = oci_fetch_array($cursor, OCI_ASSOC + OCI_RETURN_NULLS)) {
    foreach ($row as $key => $value) {
        if (is_a($value, 'OCI-Lob')) {
            $row[$key] = $value->load();
        }
    }
    $trainerReviews[] = $row;
}


$query = 'SELECT * FROM ZAJECIA';
$stid = oci_parse($conn, $query);
oci_execute($stid);

$allClasses = [];
while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
    $allClasses[] = $row;
}

oci_free_statement($stid);

$query = 'SELECT * FROM SILOWNIE';
$stid = oci_parse($conn, $query);
oci_execute($stid);

$gyms = [];
while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
    $gyms[] = $row;
}

oci_free_statement($stid);

$query = 'SELECT ID_KLIENTA, IMIE, NAZWISKO FROM KLIENCI';
$stid = oci_parse($conn, $query);
oci_execute($stid);

$clients = [];
while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
    $clients[] = $row;
}

oci_free_statement($stid);


$measurements = [];
if (isset($_GET['id_klienta'])) {
    $clientId = $_GET['id_klienta'];

    $query = "SELECT DATA, WAGA, WZROST, MASA_MIESNIOWA, TKANKA_TLUSZCZOWA
              FROM SILOWNIA.POMIARY_SKLADU_CIALA
              WHERE ID_KLIENTA = :id_klienta
              ORDER BY DATA DESC";

    $stid = oci_parse($conn, $query);
    oci_bind_by_name($stid, ':id_klienta', $clientId);
    oci_execute($stid);
    while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
        $measurements[] = $row;
    }
    oci_free_statement($stid);
}

$query = "SELECT ID_KARNETU, NAZWA FROM KARNETY";
$stid = oci_parse($conn, $query);
oci_execute($stid);

$karnety = [];
while ($row = oci_fetch_array($stid, OCI_ASSOC)) {
    $karnety[] = $row;
}

oci_free_statement($stid);


oci_close($conn);
?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta http-equiv="Content-Language" content="pl">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Trenera</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Witaj, <?php echo $_SESSION['login']; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#utworz_zajecia">Utwórz zajęcia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#karnet">Karnety</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#opinie">Sprawdź opinie</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#analiza">Analizy składu ciała</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rejestracja_trenera.php">Zarejestruj nowego trenera</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Wyloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Moje dane:</h3>
                <p class="card-text"><strong>Imię:</strong> <?php echo $trainerData['IMIE']; ?></p>
                <p class="card-text"><strong>Nazwisko:</strong> <?php echo $trainerData['NAZWISKO']; ?></p>
                <p class="card-text"><strong>Specjalizacja:</strong> <?php echo $trainerData['SPECJALIZACJA']; ?></p>
                <p class="card-text"><strong>Doświadczenie:</strong> <?php echo $trainerData['DOSWIADCZENIE']; ?> lat</p>
                <p class="card-text"><strong>Telefon:</strong> <?php echo $trainerData['TELEFON']; ?></p>
                <p class="card-text"><strong>Email:</strong> <?php echo $trainerData['EMAIL']; ?></p>
                <a href="trainer_edit_data.php" class="btn btn-primary">Edytuj</a>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Moje spotkania:</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Nazwa zajęć</th>
                            <th scope="col">Siłownia</th>
                            <th scope="col">Data i godzina</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($trainerClasses as $class) : ?>
                            <tr>
                                <td><?php echo $class['NAZWA_ZAJEC']; ?></td>
                                <td><?php echo $class['SILOWNIA']; ?></td>
                                <td>
                                    <?php
                                    $date_time = DateTime::createFromFormat('d-M-y h.i.s.u A', $class['DATA_I_GODZINA']);
                                    if ($date_time) {
                                        echo $date_time->format('d-m-Y H:i');
                                    } else {
                                        echo "Błąd parsowania daty i godziny";
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title" id="utworz_zajecia">Utwórz spotkanie:</h3>
                <form method="post" action="dodaj_spotkanie.php">
                    <div class="mb-3">
                        <label for="zajecia" class="form-label">Wybierz zajęcia</label>
                        <select class="form-select" id="zajecia" name="zajecia" required>
                            <option value="" selected disabled>Wybierz zajęcia</option>
                            <?php foreach ($allClasses as $class) : ?>
                                <option value="<?php echo $class['ID_ZAJEC']; ?>"><?php echo $class['NAZWA']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="silownia" class="form-label">Wybierz siłownię</label>
                        <select class="form-select" id="silownia" name="silownia" required>
                            <option value="" selected disabled>Wybierz siłownię</option>
                            <?php foreach ($gyms as $gym) : ?>
                                <option value="<?php echo $gym['ID_SILOWNI']; ?>"><?php echo $gym['NAZWA']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="data_i_godzina" class="form-label">Data i godzina</label>
                        <input type="datetime-local" class="form-control" id="data_i_godzina" name="data_i_godzina" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Dodaj spotkanie</button>
                </form>
            </div>
        </div>


        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Dodaj nowe zajęcia:</h3>
                <form method="post" action="dodaj_zajecia.php">
                    <div class="mb-3">
                        <label for="nazwa_zajec" class="form-label">Nazwa zajęć</label>
                        <input type="text" class="form-control" id="nazwa_zajec" name="nazwa_zajec" required>
                    </div>
                    <div class="mb-3">
                        <label for="opis" class="form-label">Opis</label>
                        <textarea class="form-control" id="opis" name="opis" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="dlugosc_trwania" class="form-label">Długość trwania (w minutach)</label>
                        <input type="number" class="form-control" id="dlugosc_trwania" name="dlugosc_trwania" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Dodaj zajęcia</button>
                </form>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title" id="opinie">Opinie:</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Ocena</th>
                            <th scope="col">Komentarz</th>
                            <th scope="col">Nazwa zajęć</th>
                            <th scope="col">Data i godzina</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($trainerReviews as $review) : ?>
                            <tr>
                                <td><?php echo $review['OCENA']; ?></td>
                                <td><?php echo $review['KOMENTARZ'] ?: '-'; ?></td>
                                <td><?php echo $review['NAZWA_ZAJEC']; ?></td>
                                <td>
                                    <?php
                                    $date_time = DateTime::createFromFormat('d-M-y h.i.s.u A', $review['DATA_I_GODZINA']);
                                    if ($date_time) {
                                        echo $date_time->format('d-m-Y H:i');
                                    } else {
                                        echo "Błąd parsowania daty i godziny";
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card mb-4" id="analizy_skladu_ciala">
            <div class="card-body">
                <h3 class="card-title">Analizy składu ciała klienta:</h3>
                <?php if (isset($_GET['id_klienta'])) : ?>
                    <?php
                    $clientId = $_GET['id_klienta'];
                    $clientName = '';
                    foreach ($clients as $client) {
                        if ($client['ID_KLIENTA'] == $clientId) {
                            $clientName = $client['IMIE'] . ' ' . $client['NAZWISKO'];
                            break;
                        }
                    }
                    ?>
                    <p class="mb-3">Analizy składu ciała: <strong><?php echo $clientName; ?></strong></p>
                <?php endif; ?>
                <form method="GET" action="#analizy_skladu_ciala">
                    <div class="mb-3">
                        <label for="select_client" class="form-label"></label>
                        <select class="form-select" id="select_client" name="id_klienta" required>
                            <option value="" selected disabled>Wybierz klienta</option>
                            <?php foreach ($clients as $client) : ?>
                                <option value="<?php echo $client['ID_KLIENTA']; ?>">
                                    <?php echo $client['IMIE'] . ' ' . $client['NAZWISKO']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Pokaż analizy</button>
                </form>

                <?php if (isset($measurements)) : ?>
                    <?php if (count($measurements) > 0) : ?>
                        <div class="accordion mt-4" id="accordionHistory">
                            <?php foreach ($measurements as $index => $measurement) : ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading<?php echo $index; ?>">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $index; ?>" aria-expanded="true" aria-controls="collapse<?php echo $index; ?>">
                                            Pomiar z <?php
                                                        $measurement_date = DateTime::createFromFormat('d-M-y', $measurement['DATA']);
                                                        if ($measurement_date) {
                                                            echo $measurement_date->format('d-m-Y');
                                                        } else {
                                                            echo "Błąd parsowania daty pomiaru";
                                                        }
                                                        ?>
                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo $index; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo $index; ?>" data-bs-parent="#accordionHistory">
                                        <div class="accordion-body">
                                            <p><strong>Waga:</strong> <?php echo $measurement['WAGA']; ?>kg</p>
                                            <p><strong>Wzrost:</strong> <?php echo $measurement['WZROST']; ?>cm</p>
                                            <p><strong>Masa mięśniowa:</strong> <?php echo $measurement['MASA_MIESNIOWA']; ?>kg</p>
                                            <p><strong>Tkanka tłuszczowa:</strong> <?php echo $measurement['TKANKA_TLUSZCZOWA']; ?>%</p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p class="mt-4">Brak danych.</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title" id="analiza">Dodaj analizę składu ciała:</h3>
                <form method="post" action="dodaj_analize.php">
                    <input type="hidden" name="id_trenera" value="<?php echo $trainerData['ID_TRENERA']; ?>">
                    <div class="mb-3">
                        <label for="id_klienta" class="form-label">Wybierz Klienta</label>
                        <select class="form-select" id="id_klienta" name="id_klienta" required>
                            <option value="" selected disabled>Wybierz klienta</option>
                            <?php foreach ($clients as $client) : ?>
                                <option value="<?php echo $client['ID_KLIENTA']; ?>">
                                    <?php echo $client['IMIE'] . ' ' . $client['NAZWISKO']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="data" class="form-label">Data</label>
                        <input type="date" class="form-control" id="data" name="data" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="waga" class="form-label">Waga</label>
                        <input type="number" step="0.1" class="form-control" id="waga" name="waga" required>
                    </div>
                    <div class="mb-3">
                        <label for="wzrost" class="form-label">Wzrost</label>
                        <input type="number" step="0.1" class="form-control" id="wzrost" name="wzrost" required>
                    </div>
                    <div class="mb-3">
                        <label for="masa_miesniowa" class="form-label">Masa mięśniowa</label>
                        <input type="number" step="0.1" class="form-control" id="masa_miesniowa" name="masa_miesniowa" required>
                    </div>
                    <div class="mb-3">
                        <label for="tkanka_tluszczowa" class="form-label">Tkanka tłuszczowa</label>
                        <input type="number" step="0.1" class="form-control" id="tkanka_tluszczowa" name="tkanka_tluszczowa" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Dodaj analizę</button>
                </form>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title" id="karnet">Dodaj nowy karnet:</h3>
                <form method="post" action="utworz_karnet.php">
                    <div class="mb-3">
                        <label for="nazwa_karnetu" class="form-label">Nazwa karnetu</label>
                        <input type="text" class="form-control" id="nazwa_karnetu" name="nazwa_karnetu" required>
                    </div>
                    <div class="mb-3">
                        <label for="opis" class="form-label">Opis</label>
                        <textarea class="form-control" id="opis" name="opis" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="cena" class="form-label">Cena</label>
                        <input type="number" step="0.01" class="form-control" id="cena" name="cena" required>
                    </div>
                    <div class="mb-3">
                        <label for="dlugosc_trwania" class="form-label">Długość trwania (w dniach)</label>
                        <input type="number" class="form-control" id="dlugosc_trwania" name="dlugosc_trwania" required>
                    </div>
                    <div class="mb-3">
                        <label for="typ" class="form-label">Typ</label>
                        <input type="text" class="form-control" id="typ" name="typ" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Dodaj karnet</button>
                </form>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h1>Edytuj Karnet</h1><br>
                <form method="post" action="karnet_edycja.php">
                    <div class="mb-3">
                        <label for="id_karnetu" class="form-label">Wybierz Karnet</label>
                        <select class="form-select" id="id_karnetu" name="id_karnetu" required>
                            <option value="" selected disabled>Wybierz karnet</option>
                            <?php foreach ($karnety as $karnet) : ?>
                                <option value="<?php echo $karnet['ID_KARNETU']; ?>">
                                    <?php echo $karnet['NAZWA']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="nazwa_karnetu" class="form-label">Nazwa karnetu</label>
                        <input type="text" class="form-control" id="nazwa_karnetu" name="nazwa_karnetu" required>
                    </div>
                    <div class="mb-3">
                        <label for="opis" class="form-label">Opis</label>
                        <textarea class="form-control" id="opis" name="opis" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="cena" class="form-label">Cena</label>
                        <input type="number" step="0.01" class="form-control" id="cena" name="cena" required>
                    </div>
                    <div class="mb-3">
                        <label for="dlugosc_trwania" class="form-label">Długość trwania (w dniach)</label>
                        <input type="number" class="form-control" id="dlugosc_trwania" name="dlugosc_trwania" required>
                    </div>
                    <div class="mb-3">
                        <label for="typ" class="form-label">Typ</label>
                        <input type="text" class="form-control" id="typ" name="typ" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Zapisz zmiany</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>