<?php
session_start();
$type = $_SESSION['type'] ?? 'client';
session_destroy();
header("Location: login.php?type=$type");
exit();
?>
