<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}

include 'connection.php';
$conn = getConnection();

$p_nazwa_karnetu = $_POST['nazwa_karnetu'];
$p_opis = $_POST['opis'];
$p_cena = $_POST['cena'];
$p_dlugosc_trwania = $_POST['dlugosc_trwania'];
$p_typ = $_POST['typ'];

$query = 'BEGIN TRAINER_FUNCTIONS.DODAJ_KARNET(:p_nazwa_karnetu, :p_opis, :p_cena, :p_dlugosc_trwania, :p_typ); END;';
$stid = oci_parse($conn, $query);

oci_bind_by_name($stid, ':p_nazwa_karnetu', $p_nazwa_karnetu);
oci_bind_by_name($stid, ':p_opis', $p_opis);
oci_bind_by_name($stid, ':p_cena', $p_cena);
oci_bind_by_name($stid, ':p_dlugosc_trwania', $p_dlugosc_trwania);
oci_bind_by_name($stid, ':p_typ', $p_typ);

oci_execute($stid);
oci_free_statement($stid);
oci_close($conn);

header("Location: trainer_dashboard.php"); 
exit();
?>
