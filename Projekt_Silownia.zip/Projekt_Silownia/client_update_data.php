<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'client') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'connection.php';
    $conn = getConnection();

    $id_klienta = $_POST['id_klienta'];
    $imie = $_POST['imie'];
    $nazwisko = $_POST['nazwisko'];
    $adres = $_POST['adres'];
    $telefon = $_POST['telefon'];
    $email = $_POST['email'];
    $data_urodzenia = DateTime::createFromFormat('Y-m-d', $_POST['data_urodzenia'])->format('d-M-y');

    $query = "SELECT email FROM KLIENCI WHERE ID_KLIENTA = :id_klienta";
    $statement = oci_parse($conn, $query);
    oci_bind_by_name($statement, ':id_klienta', $id_klienta);
    oci_execute($statement);
    $row = oci_fetch_assoc($statement);
    $old_email = $row['EMAIL'];
    oci_free_statement($statement);

    $query = "BEGIN KLIENT_FUNCTIONS.client_update_data(KLIENT_FUNCTIONS.ClientData(:id_klienta, :imie, :nazwisko, :telefon, :email, :data_urodzenia, :adres)); END;";
    $statement = oci_parse($conn, $query);

    oci_bind_by_name($statement, ':id_klienta', $id_klienta);
    oci_bind_by_name($statement, ':imie', $imie);
    oci_bind_by_name($statement, ':nazwisko', $nazwisko);
    oci_bind_by_name($statement, ':telefon', $telefon);
    oci_bind_by_name($statement, ':email', $email);
    oci_bind_by_name($statement, ':data_urodzenia', $data_urodzenia);
    oci_bind_by_name($statement, ':adres', $adres);

    if (oci_execute($statement)) {
        if ($email != $old_email) {
            session_destroy();
            header("Location: login.php");
            exit();
        } else {
            $_SESSION['karnet_message'] = "Dane zostały pomyślnie zaktualizowane.";
        }
    } else {
        $_SESSION['karnet_message'] = "Błąd aktualizacji danych email";
    }

    oci_free_statement($statement);
    oci_close($conn);
    header("Location: client_dashboard.php");
    exit();
} else {
    header("Location: client_dashboard.php");
    exit();
}
