<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'client') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_prowadzenia = $_POST['id_prowadzenia'];

    include 'connection.php';
    $conn = getConnection();
    $login = $_SESSION['login'];

    $stmt = oci_parse($conn, "SELECT ID_KLIENTA FROM KLIENCI WHERE EMAIL = :login");
    oci_bind_by_name($stmt, ":login", $login);
    oci_execute($stmt);
    $row = oci_fetch_assoc($stmt);
    $id_klienta = $row['ID_KLIENTA'];

    $stmt = oci_parse($conn, "BEGIN KLIENT_FUNCTIONS.ZAPISZ_SIE(:p_id_klienta, :p_id_prowadzenia); END;");
    oci_bind_by_name($stmt, ":p_id_klienta", $id_klienta);
    oci_bind_by_name($stmt, ":p_id_prowadzenia", $id_prowadzenia);

    $result = oci_execute($stmt);
    if (!$result) {
        $error = oci_error($stmt);
        $errorMessage = explode('ORA-06512', $error['message'])[0];
        $_SESSION['error'] = $errorMessage;
    }

    header("Location: zapis_na_zajecia.php");
    exit();
    
}
oci_close($conn);
?>