<?php
function getConnection() {
    $conn = oci_connect("silownia", "silownia", "localhost:1521/freepdb1");
    if (!$conn) {
        $m = oci_error();
        echo $m['message'], "\n";
        exit;
    }
    return $conn;
}
?>
