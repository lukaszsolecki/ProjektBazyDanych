<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}

include 'connection.php';
$conn = getConnection();
$login = $_SESSION['login'];

$query = "BEGIN TRAINER_FUNCTIONS.POBIERZ_DANE_TRENERA(:p_cursor, :p_login); END;";
$statement = oci_parse($conn, $query);
$cursor = oci_new_cursor($conn);
oci_bind_by_name($statement, ':p_cursor', $cursor, -1, OCI_B_CURSOR);
oci_bind_by_name($statement, ':p_login', $login);
oci_execute($statement);
oci_execute($cursor);
$trainerData = oci_fetch_assoc($cursor);

oci_free_statement($statement);
oci_close($conn);
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edytuj dane klienta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="trainer_dashboard.php">Witaj, <?php echo $_SESSION['login']; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#utworz_zajecia">Utwórz zajęcia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#karnet">Karnety</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#opinie">Sprawdź opinie</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#analiza">Analizy składu ciała</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rejestracja_trenera.php">Zarejestruj nowego trenera</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Wyloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4">Edytuj dane trenera</h1>
        <form action="trainer_update_data.php" method="post">
            <div class="mb-3">
                <label for="imie" class="form-label">Imię</label>
                <input type="text" class="form-control" id="imie" name="imie" value="<?php echo $trainerData['IMIE']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="nazwisko" class="form-label">Nazwisko</label>
                <input type="text" class="form-control" id="nazwisko" name="nazwisko" value="<?php echo $trainerData['NAZWISKO']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="adres" class="form-label">Specjalizacja</label>
                <input type="text" class="form-control" id="specjalizacja" name="specjalizacja" value="<?php echo $trainerData['SPECJALIZACJA']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="telefon" class="form-label">Doświadczenie</label>
                <input type="text" class="form-control" id="doswiadczenie" name="doswiadczenie" value="<?php echo $trainerData['DOSWIADCZENIE']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="telefon" class="form-label">Telefon</label>
                <input type="text" class="form-control" id="telefon" name="telefon" value="<?php echo $trainerData['TELEFON']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo $trainerData['EMAIL']; ?>" required>
            </div>
            <input type="hidden" name="id_trenera" value="<?php echo $trainerData['ID_TRENERA']; ?>">
            <button type="submit" class="btn btn-primary">Zapisz zmiany</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>