<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'connection.php';
    $conn = getConnection();

    $id_trenera = $_POST['id_trenera'];
    $imie = $_POST['imie'];
    $nazwisko = $_POST['nazwisko'];
    $specjalizacja = $_POST['specjalizacja'];
    $doswiadczenie = $_POST['doswiadczenie'];
    $telefon = $_POST['telefon'];
    $email = $_POST['email'];


    $query = "SELECT email FROM TRENERZY WHERE ID_TRENERA = :id_trenera";
    $statement = oci_parse($conn, $query);
    oci_bind_by_name($statement, ':id_trenera', $id_trenera);
    oci_execute($statement);
    $row = oci_fetch_assoc($statement);
    $old_email = $row['EMAIL'];
    oci_free_statement($statement);

    $query = "BEGIN TRAINER_FUNCTIONS.trainer_update_data(TRAINER_FUNCTIONS.TrainerData(:id_trenera, :imie, :nazwisko, :specjalizacja, :doswiadczenie, :telefon, :email)); END;";
    $statement = oci_parse($conn, $query);

    oci_bind_by_name($statement, ':id_trenera', $id_trenera);
    oci_bind_by_name($statement, ':imie', $imie);
    oci_bind_by_name($statement, ':nazwisko', $nazwisko);
    oci_bind_by_name($statement, ':specjalizacja', $specjalizacja);
    oci_bind_by_name($statement, ':doswiadczenie', $doswiadczenie);
    oci_bind_by_name($statement, ':telefon', $telefon);
    oci_bind_by_name($statement, ':email', $email);


    if (oci_execute($statement)) {
        if ($email != $old_email) {
            session_destroy();
            header("Location: login.php");
            exit();
        } else {
            $_SESSION['karnet_message'] = "Dane zostały pomyślnie zaktualizowane.";
        }
    } else {
        $_SESSION['karnet_message'] = "Błąd aktualizacji danych email";
    }

    oci_free_statement($statement);
    oci_close($conn);
    header("Location: trainer_dashboard.php");
    exit();
} else {
    header("Location: trainer_dashboard.php");
    exit();
}
