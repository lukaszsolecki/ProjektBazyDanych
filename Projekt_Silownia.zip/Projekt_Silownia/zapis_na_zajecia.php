<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'client') {
    header("Location: login.php");
    exit();
}

include 'connection.php';
$conn = getConnection();
$login = $_SESSION['login'];

$stmt_check_karnet = oci_parse($conn, "SELECT AKTYWNY FROM KLIENCI WHERE EMAIL = :login");
oci_bind_by_name($stmt_check_karnet, ":login", $login);
oci_execute($stmt_check_karnet);
$row_karnet = oci_fetch_assoc($stmt_check_karnet);
$aktywny_karnet = $row_karnet['AKTYWNY'];

if ($aktywny_karnet == 'N') {
    header("Location: client_dashboard.php?error=Twój+karnet+jest+nieaktywny+,+nie+możesz+zapisywać+się+na+zajęcia.");
    exit();
}

$stmt = oci_parse($conn, "BEGIN KLIENT_FUNCTIONS.POBIERZ_ZAJECIA(:p_cursor); END;");
$cursor = oci_new_cursor($conn);
oci_bind_by_name($stmt, ":p_cursor", $cursor, -1, OCI_B_CURSOR);
oci_execute($stmt);
oci_execute($cursor);
oci_close($conn);

?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zapis na zajęcia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="client_dashboard.php">Witaj, <?php echo $_SESSION['login']; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="zapis_na_zajecia.php">Zapisz się na zajęcia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="wystaw_opinie.php">Wystaw opinię</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kup_karnet.php">Kup karnet</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="opinie.php">Zobacz opinie</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Wyloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($_SESSION['error']) && !empty($_SESSION['error'])) : ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $_SESSION['error'];
                unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
        <h1>Wybierz zajęcia</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>Nazwa zajęć</th>
                    <th>Trener</th>
                    <th>Siłownia</th>
                    <th>Data i godzina</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = oci_fetch_assoc($cursor)) {
                    echo "<tr>";
                    echo "<td>" . $row['NAZWA_ZAJEC'] . "</td>";
                    echo "<td>" . $row['TRENER'] . "</td>";
                    echo "<td>" . $row['SILOWNIA'] . "</td>";
                    $date_time = DateTime::createFromFormat('d-M-y h.i.s.u A', $row['DATA_I_GODZINA']);
                    if ($date_time) {
                        echo "<td>" . $date_time->format('d-m-Y H:i') . "</td>";
                    } else {
                        echo "<td>Błąd parsowania daty i godziny</td>";
                    }
                    echo "<td>";

                    $stmt_check = oci_parse($conn, "BEGIN KLIENT_FUNCTIONS.SPRAWDZ_ZAPIS(:p_login, :p_id_prowadzenia, :p_result); END;");
                    oci_bind_by_name($stmt_check, ":p_login", $login);
                    oci_bind_by_name($stmt_check, ":p_id_prowadzenia", $row['ID_PROWADZENIA']);
                    oci_bind_by_name($stmt_check, ":p_result", $result, 5);

                    oci_execute($stmt_check);

                    if ($result == 'TRUE') {
                        echo "Jesteś już zapisany na te zajęcia.";
                    } else {
                        echo "<form action='zapisz_sie.php' method='post'>";
                        echo "<input type='hidden' name='id_prowadzenia' value='" . $row['ID_PROWADZENIA'] . "'/>";
                        echo "<input type='submit' value='Zapisz się'/>";
                        echo "</form>";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
                ?>

            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>