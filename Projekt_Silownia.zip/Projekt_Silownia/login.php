<?php
session_start();
include 'connection.php';

$type = $_GET['type'] ?? 'client';

if (isset($_POST['login']) && isset($_POST['password'])) {
    $login = $_POST['login'];
    $password = $_POST['password'];

    if (validateLogin($login, $password, $type)) {
        if ($type == 'client') {
            updateClientStatusIfNeeded($login);
        }

        $_SESSION['login'] = $login;
        $_SESSION['type'] = $type;
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Nieprawidłowy login lub hasło!";
    }
}

function validateLogin($login, $password, $type)
{
    $conn = getConnection();
    if ($type == 'client') {
        $query = "SELECT KLIENT_FUNCTIONS.ValidateLogin(:p_login, :p_password) FROM DUAL";
    } else if ($type == 'trainer') {
        $query = "SELECT TRAINER_FUNCTIONS.ValidateTrainerLogin(:p_login, :p_password) FROM DUAL";
    } else {
        return false;
    }

    $stid = oci_parse($conn, $query);
    oci_bind_by_name($stid, ':p_login', $login);
    oci_bind_by_name($stid, ':p_password', $password);
    oci_execute($stid);
    $result = oci_fetch_row($stid);
    oci_free_statement($stid);
    oci_close($conn);
    return $result ? intval($result[0]) === 1 : false;
}

function updateClientStatusIfNeeded($login)
{
    $conn = getConnection();
    $query = "BEGIN KLIENT_FUNCTIONS.UpdateClientStatus(:p_login); END;";
    $stid = oci_parse($conn, $query);
    oci_bind_by_name($stid, ':p_login', $login);
    oci_execute($stid);
    oci_free_statement($stid);
    oci_close($conn);
}
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta http-equiv="Content-Language" content="pl">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie - Silownia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Witamy w naszej sieci siłowni!</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <?php if ($type != 'trainer') : ?>
                        <li class="nav-item">
                            <a class="nav-link" href="rejestracja.php">Zarejestruj się</a>
                        </li>
                    <?php endif; ?>
                    <?php if ($type == 'client') : ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php?type=trainer">Panel trenera</a>
                        </li>
                    <?php endif; ?>
                    <?php if ($type == 'trainer') : ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php?type=client">Panel klienta</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5">
                    <div class="card-header">
                        <h3>Logowanie <?php echo $type == 'client' ? 'klienta' : 'trenera'; ?></h3>
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="login" class="form-label">Login:</label>
                                <input type="text" class="form-control" id="login" name="login" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Hasło:</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Zaloguj się</button>
                            <?php if (isset($error)) echo "<p class='text-danger mt-3'>$error</p>"; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>