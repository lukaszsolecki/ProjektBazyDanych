<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    include 'connection.php';
    $conn = getConnection();

    $id_klienta = $_POST['id_klienta'];
    $data = date('Y-m-d H:i:s', strtotime($_POST['data']));
    $waga = $_POST['waga'];
    $wzrost = $_POST['wzrost'];
    $masa_miesniowa = $_POST['masa_miesniowa'];
    $tkanka_tluszczowa = $_POST['tkanka_tluszczowa'];

    $query_call_procedure = 'BEGIN TRAINER_FUNCTIONS.DODAJ_ANALIZE_SKLADU_CIALA(:id_klienta, TO_TIMESTAMP(:data, \'YYYY-MM-DD HH24:MI:SS\'), :waga, :wzrost, :masa_miesniowa, :tkanka_tluszczowa); END;';
    $stid = oci_parse($conn, $query_call_procedure);
    oci_bind_by_name($stid, ':id_klienta', $id_klienta);
    oci_bind_by_name($stid, ':data', $data);
    oci_bind_by_name($stid, ':waga', $waga);
    oci_bind_by_name($stid, ':wzrost', $wzrost);
    oci_bind_by_name($stid, ':masa_miesniowa', $masa_miesniowa);
    oci_bind_by_name($stid, ':tkanka_tluszczowa', $tkanka_tluszczowa);
    oci_execute($stid);

    oci_free_statement($stid);
    oci_close($conn);

    header("Location: trainer_dashboard.php");
    exit();
}
?>
