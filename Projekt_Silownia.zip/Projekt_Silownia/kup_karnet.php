<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['type'] != 'client') {
    header("Location: login.php");
    exit();
}

include 'connection.php';

$conn = getConnection();
$login = $_SESSION['login'];
$query = 'SELECT id_klienta FROM klienci WHERE email = :email';
$stid = oci_parse($conn, $query);
oci_bind_by_name($stid, ':email', $login);
oci_execute($stid);

$row = oci_fetch_assoc($stid);
if (!$row) {
    echo '<div class="alert alert-danger" role="alert">Błąd: nie znaleziono klienta z podanym adresem email.</div>';
    exit();
}

$klient_id = $row['ID_KLIENTA'];
oci_free_statement($stid);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $karnet_id = $_POST['karnet_id'];

    if (!$klient_id || !$karnet_id) {
        echo '<div class="alert alert-danger" role="alert">Błąd: brak ID klienta lub karnetu.</div>';
        exit;
    }

    $query = 'BEGIN KLIENT_FUNCTIONS.kup_karnet(:klient_id, :karnet_id); END;';
    $stid = oci_parse($conn, $query);
    oci_bind_by_name($stid, ':klient_id', $klient_id);
    oci_bind_by_name($stid, ':karnet_id', $karnet_id);

    if (oci_execute($stid)) { 
        $_SESSION['karnet_message'] = 'Karnet został pomyślnie zaktualizowany.';
        header("Location: client_dashboard.php");
        exit();
    } else {
        $e = oci_error($stid);
        echo '<div class="alert alert-danger" role="alert">Błąd wykonania procedury: ' . htmlspecialchars($e['message']) . '</div>';
    }
    

    oci_free_statement($stid);
    oci_close($conn);
} else {
    $query = 'SELECT id_karnetu, nazwa, opis, cena, dlugosc_trwania, typ FROM karnety';
    $stid = oci_parse($conn, $query);
    oci_execute($stid);
?>
    <!DOCTYPE html>
    <html lang="pl">

    <head>
        <meta http-equiv="Content-Language" content="pl">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Wybierz Karnet</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="client_dashboard.php">Witaj, <?php echo $_SESSION['login']; ?></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="zapis_na_zajecia.php">Zapisz się na zajęcia</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="wystaw_opinie.php">Wystaw opinię</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="kup_karnet.php">Aktualizuj karnet</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="opinie.php">Zobacz opinie</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Wyloguj</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h3>Wybierz Karnet</h3>
                        </div>
                        <div class="card-body">
                            <form method="post" action="">
                                <div class="mb-3">
                                    <label for="karnet_id" class="form-label">Dostępne Karnety</label>
                                    <select class="form-select" id="karnet_id" name="karnet_id" required>
                                        <?php
                                        while ($row = oci_fetch_assoc($stid)) {
                                            echo '<option value="' . $row['ID_KARNETU'] . '">' . htmlspecialchars($row['NAZWA']) . ' - ' . htmlspecialchars($row['OPIS']) . ' - ' . htmlspecialchars($row['CENA']) . ' PLN - ' . htmlspecialchars($row['DLUGOSC_TRWANIA']) . ' dni - ' . htmlspecialchars($row['TYP']) . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">Zapisz</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>

    </html>
<?php
    oci_free_statement($stid);
    oci_close($conn);
}
?>