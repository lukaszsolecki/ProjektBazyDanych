<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    include 'connection.php';
    $conn = getConnection();
    $login = $_SESSION['login'];

    $query_get_trainer_id = "SELECT ID_TRENERA FROM TRENERZY WHERE EMAIL = :login";
    $stid_get_trainer_id = oci_parse($conn, $query_get_trainer_id);
    oci_bind_by_name($stid_get_trainer_id, ":login", $login);
    oci_execute($stid_get_trainer_id);
    $trainer_row = oci_fetch_assoc($stid_get_trainer_id);
    oci_free_statement($stid_get_trainer_id);
    $id_trenera = $trainer_row['ID_TRENERA'];


    $id_zajec = $_POST['zajecia'];
    $id_silowni = $_POST['silownia'];
    $data_i_godzina = date('Y-m-d H:i:s', strtotime($_POST['data_i_godzina']));

    $query_call_procedure = 'BEGIN TRAINER_FUNCTIONS.DODAJ_SPOTKANIE(:id_trenera, :id_zajec, :id_silowni, TO_TIMESTAMP(:data_i_godzina, \'YYYY-MM-DD HH24:MI:SS\')); END;';
    $stid_call_procedure = oci_parse($conn, $query_call_procedure);
    oci_bind_by_name($stid_call_procedure, ':id_trenera', $id_trenera);
    oci_bind_by_name($stid_call_procedure, ':id_zajec', $id_zajec);
    oci_bind_by_name($stid_call_procedure, ':id_silowni', $id_silowni);
    oci_bind_by_name($stid_call_procedure, ':data_i_godzina', $data_i_godzina);
    oci_execute($stid_call_procedure);

    oci_free_statement($stid_call_procedure);
    oci_close($conn);

    header("Location: trainer_dashboard.php");

    exit();
}
oci_close($conn);
