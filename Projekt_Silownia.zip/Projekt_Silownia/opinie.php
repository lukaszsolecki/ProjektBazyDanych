<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'client') {
    header("Location: login.php");
    exit();
}

include 'connection.php';

function fetchOcenySilowni()
{
    $conn = getConnection();
    $sql = "BEGIN KLIENT_FUNCTIONS.OCENY_SILOWNI(:p_cursor); END;";
    $stid = oci_parse($conn, $sql);

    $p_cursor = oci_new_cursor($conn);
    oci_bind_by_name($stid, ":p_cursor", $p_cursor, -1, OCI_B_CURSOR);

    if (!oci_execute($stid)) {
        $e = oci_error($stid);
        echo '<div class="alert alert-danger" role="alert">Błąd wykonania procedury: ' . htmlspecialchars($e['message']) . '</div>';
        return [];
    }

    oci_execute($p_cursor);

    $result = [];
    while (($row = oci_fetch_assoc($p_cursor)) != false) {
        $result[] = $row;
    }

    oci_free_statement($stid);
    oci_free_statement($p_cursor);
    oci_close($conn);

    return $result;
}


function fetchOcenyTrenerow()
{
    $conn = getConnection();
    $sql = "BEGIN KLIENT_FUNCTIONS.OCENY_TRENEROW(:p_cursor); END;";
    $stid = oci_parse($conn, $sql);

    $p_cursor = oci_new_cursor($conn);
    oci_bind_by_name($stid, ":p_cursor", $p_cursor, -1, OCI_B_CURSOR);

    if (!oci_execute($stid)) {
        $e = oci_error($stid);
        echo '<div class="alert alert-danger" role="alert">Błąd wykonania procedury: ' . htmlspecialchars($e['message']) . '</div>';
        return;
    }

    oci_execute($p_cursor);

    $result = [];
    while (($row = oci_fetch_assoc($p_cursor)) != false) {
        $result[] = $row;
    }

    oci_free_statement($stid);
    oci_free_statement($p_cursor);
    oci_close($conn);

    return $result;
}

function fetchOcenyZajec()
{
    $conn = getConnection();
    $sql = "BEGIN KLIENT_FUNCTIONS.OCENY_ZAJEC(:p_cursor); END;";
    $stid = oci_parse($conn, $sql);

    $p_cursor = oci_new_cursor($conn);
    oci_bind_by_name($stid, ":p_cursor", $p_cursor, -1, OCI_B_CURSOR);

    if (!oci_execute($stid)) {
        $e = oci_error($stid);
        echo '<div class="alert alert-danger" role="alert">Błąd wykonania procedury: ' . htmlspecialchars($e['message']) . '</div>';
        return [];
    }

    oci_execute($p_cursor);

    $result = [];
    while (($row = oci_fetch_assoc($p_cursor)) != false) {
        $result[] = $row;
    }

    oci_free_statement($stid);
    oci_free_statement($p_cursor);
    oci_close($conn);

    return $result;
}



$opinionGym = fetchOcenySilowni();
$opinionTrainer = fetchOcenyTrenerow();
$opinionClasses = fetchOcenyZajec();

?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta http-equiv="Content-Language" content="pl">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opinie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .section-header {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }

        .accordion-button {
            background-color: #e9ecef;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="client_dashboard.php">Witaj, <?php echo $_SESSION['login']; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="zapis_na_zajecia.php">Zapisz się na zajęcia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="wystaw_opinie.php">Wystaw opinię</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kup_karnet.php">Kup karnet</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="opinie.php">Zobacz opinie</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Wyloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Opinie siłowni</h3>
                <?php if (empty($opinionGym)) : ?>
                    <p>Brak danych</p>
                <?php else : ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Siłownia</th>
                                <th scope="col">Średnia ocen</th>
                                <th scope="col">Liczba ocen</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($opinionGym as $opinion) : ?>
                                <tr>
                                    <td><?php echo $opinion['NAZWA_SILOWNI']; ?></td>
                                    <td><?php echo number_format($opinion['SREDNIA_OCEN'], 2); ?></td>
                                    <td><?php echo $opinion['LICZBA_OCEN']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Opinie trenerów</h3>
                <?php if (empty($opinionTrainer)) : ?>
                    <p>Brak danych</p>
                <?php else : ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Trener</th>
                                <th scope="col">Średnia ocen</th>
                                <th scope="col">Liczba ocen</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($opinionTrainer as $opinion) : ?>
                                <tr>
                                    <td><?php echo $opinion['TRENER']; ?></td>
                                    <td><?php echo number_format($opinion['SREDNIA_OCEN'], 2); ?></td>
                                    <td><?php echo $opinion['LICZBA_OCEN']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Opinie Zajęć</h3>
                <?php if (empty($opinionClasses)) : ?>
                    <p>Brak danych</p>
                <?php else : ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Zajęcia</th>
                                <th scope="col">Średnia ocen</th>
                                <th scope="col">Liczba ocen</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($opinionClasses as $opinion) : ?>
                                <tr>
                                    <td><?php echo $opinion['ZAJECIA']; ?></td>
                                    <td><?php echo number_format($opinion['SREDNIA_OCEN'], 2); ?></td>
                                    <td><?php echo $opinion['LICZBA_OCEN']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const showCommentsBtns = document.querySelectorAll('.show-comments-btn');

                showCommentsBtns.forEach(btn => {
                    btn.addEventListener('click', function() {
                        const commentsData = JSON.parse(this.getAttribute('data-comments'));
                        const commentElements = this.parentNode.querySelectorAll('.comment');

                        let visibleCommentIndex = 0;
                        commentElements.forEach((comment, index) => {
                            if (comment.style.display !== 'none') {
                                visibleCommentIndex = index;
                                return;
                            }
                        });

                        commentElements[visibleCommentIndex].style.display = 'none';

                        const nextCommentIndex = (visibleCommentIndex + 1) % commentsData.length;

                        commentElements[nextCommentIndex].style.display = 'block';
                    });
                });
            });
        </script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>