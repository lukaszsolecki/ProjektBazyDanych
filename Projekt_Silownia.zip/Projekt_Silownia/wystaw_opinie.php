<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'client') {
    header("Location: login.php");
    exit();
}

include 'connection.php';
$conn = getConnection();
$login = $_SESSION['login'];

$query = "SELECT id_klienta FROM klienci WHERE EMAIL = :email";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":email", $login);
oci_execute($stmt);
$row = oci_fetch_assoc($stmt);
$id_klienta = $row['ID_KLIENTA'];
oci_free_statement($stmt);

$query = "SELECT p.id_prowadzenia, p.data_i_godzina, z.nazwa
          FROM prowadzenie p
          INNER JOIN uczestnictwo u ON p.id_prowadzenia = u.id_prowadzenia
          INNER JOIN zajecia z ON p.id_zajec = z.id_zajec
          WHERE u.id_klienta = :id_klienta
          AND p.data_i_godzina <= SYSDATE";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":id_klienta", $id_klienta);
oci_execute($stmt);

$zajecia = array();

while ($row = oci_fetch_assoc($stmt)) {
    $zajecia[] = $row;
}

oci_free_statement($stmt);

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_prowadzenia = $_POST['zajecia'];
    $ocena = $_POST['ocena'];
    $komentarz = $_POST['komentarz'];

    $query = "SELECT id_uczestnictwo FROM uczestnictwo WHERE id_prowadzenia = :id_prowadzenia AND id_klienta = :id_klienta";
    $stmt = oci_parse($conn, $query);
    oci_bind_by_name($stmt, ":id_prowadzenia", $id_prowadzenia);
    oci_bind_by_name($stmt, ":id_klienta", $id_klienta);
    oci_execute($stmt);
    $row = oci_fetch_assoc($stmt);
    $id_uczestnictwo = $row['ID_UCZESTNICTWO'];
    oci_free_statement($stmt);

    $query = "INSERT INTO opinie (id_opinii, ocena, komentarz, id_uczestnictwo) VALUES (opinie_id.NEXTVAL, :ocena, :komentarz, :id_uczestnictwo)";
    $stmt = oci_parse($conn, $query);
    oci_bind_by_name($stmt, ":ocena", $ocena);
    oci_bind_by_name($stmt, ":komentarz", $komentarz);
    oci_bind_by_name($stmt, ":id_uczestnictwo", $id_uczestnictwo);

    if (oci_execute($stmt)) {
        oci_commit($conn);
        $message = "Opinia została pomyślnie dodana.";
    } else {
        $e = oci_error($stmt);
        $message = "Błąd podczas dodawania opinii: " . htmlentities($e['message']);
    }
    oci_free_statement($stmt);
}

$query = "SELECT o.ocena, o.komentarz, p.data_i_godzina, z.nazwa
          FROM opinie o
          INNER JOIN uczestnictwo u ON o.id_uczestnictwo = u.id_uczestnictwo
          INNER JOIN prowadzenie p ON u.id_prowadzenia = p.id_prowadzenia
          INNER JOIN zajecia z ON p.id_zajec = z.id_zajec
          WHERE u.id_klienta = :id_klienta";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":id_klienta", $id_klienta);
oci_execute($stmt);

$opinie = array();

while ($row = oci_fetch_assoc($stmt)) {
    if ($row['KOMENTARZ'] !== null) {
        $komentarz_clob = $row['KOMENTARZ'];
        $row['KOMENTARZ'] = $komentarz_clob->read($komentarz_clob->size());
    } else {
        $row['KOMENTARZ'] = null;
    }
    $opinie[] = $row;
}

oci_free_statement($stmt);
oci_close($conn);
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wystaw Opinię</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="client_dashboard.php">Witaj, <?php echo $_SESSION['login']; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="zapis_na_zajecia.php">Zapisz się na zajęcia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="wystaw_opinie.php">Wystaw opinię</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kup_karnet.php">Kup karnet</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="opinie.php">Zobacz opinie</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Wyloguj</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1>Wystaw Opinię</h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="mb-3">
                <label for="zajecia" class="form-label">Wybierz zajęcia:</label>
                <select class="form-select" id="zajecia" name="zajecia" required>
                    <option value="" disabled selected>Wybierz zajęcia</option>
                    <?php foreach ($zajecia as $zajecie) : ?>
                        <option value="<?php echo $zajecie['ID_PROWADZENIA']; ?>"><?php echo $zajecie['NAZWA']; ?> - <?php
                                                                                                                        $date_time = DateTime::createFromFormat('d-M-y h.i.s.u A', $zajecie['DATA_I_GODZINA']);
                                                                                                                        if ($date_time) {
                                                                                                                            echo $date_time->format('d-m-Y H:i');
                                                                                                                        } else {
                                                                                                                            echo "Błąd parsowania daty i godziny";
                                                                                                                        }
                                                                                                                        ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="ocena" class="form-label">Ocena (od 1 do 5)</label>
                <input type="number" class="form-control" id="ocena" name="ocena" min="1" max="5" required>
            </div>
            <div class="mb-3">
                <label for="komentarz" class="form-label">Komentarz</label>
                <textarea class="form-control" id="komentarz" name="komentarz" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Wystaw opinię</button>
        </form>
    </div><br><br>
    <div class="container">
        <h2>Twoje Opinie</h2>
        <?php if (empty($opinie)) : ?>
            <p>Brak danych</p>
        <?php else : ?>
            <?php foreach ($opinie as $opinia) : ?>
                <div class="card mb-3">
                    <div class="card-header">
                        <?php echo htmlspecialchars($opinia['NAZWA']); ?> - <?php
                                                                            $date_time = DateTime::createFromFormat('d-M-y h.i.s.u A', $opinia['DATA_I_GODZINA']);
                                                                            if ($date_time) {
                                                                                echo $date_time->format('d-m-Y H:i');
                                                                            } else {
                                                                                echo "Błąd parsowania daty i godziny";
                                                                            }
                                                                            ?>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Ocena: <?php echo htmlspecialchars($opinia['OCENA']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars($opinia['KOMENTARZ']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>