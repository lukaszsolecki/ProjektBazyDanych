<!DOCTYPE html>
<html lang="pl">

<head>
    <meta http-equiv="Content-Language" content="pl">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Witamy w naszej siłowni</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-image: url('images/silownia.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: white;
        }

        .navbar {
            background-color: rgba(0, 0, 0, 0.5);
        }

        .btn-primary {
            background-color: rgba(0, 0, 0, 0.7);
            border-color: rgba(0, 0, 0, 0.7);
            width: 200px;
            margin: 10px;
            font-size: 20px;
        }

        .btn-primary:hover {
            background-color: rgba(0, 0, 0, 0.9);
            border-color: rgba(0, 0, 0, 0.9);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Witamy w naszej sieci siłowni!</a>
        </div>
    </nav>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 text-center">
                <a href="login.php?type=client" class="btn btn-primary btn-lg mt-5">Panel klienta</a>
                <a href="login.php?type=trainer" class="btn btn-primary btn-lg mt-5">Panel trenera</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>