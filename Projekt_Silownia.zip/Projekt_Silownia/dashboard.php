<?php
session_start();
if (!isset($_SESSION['login']) || !isset($_SESSION['type'])) {
    header("Location: login.php");
    exit();
}

$login = $_SESSION['login'];
$type = $_SESSION['type'];

if ($type == 'client') {
    header("Location: client_dashboard.php");
    exit();
} elseif ($type == 'trainer') {
    header("Location: trainer_dashboard.php");
    exit();
}
?>
