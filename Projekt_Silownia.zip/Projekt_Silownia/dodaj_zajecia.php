<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}

include 'connection.php';
$conn = getConnection();
$login = $_SESSION['login'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nazwa_zajec = $_POST['nazwa_zajec'];
    $opis = $_POST['opis'];
    $dlugosc_trwania = $_POST['dlugosc_trwania'];

    $query = 'BEGIN TRAINER_FUNCTIONS.DODAJ_ZAJECIA(:nazwa_zajec, :opis, :dlugosc_trwania); END;';
    $stid = oci_parse($conn, $query);
    oci_bind_by_name($stid, ':nazwa_zajec', $nazwa_zajec);
    oci_bind_by_name($stid, ':opis', $opis);
    oci_bind_by_name($stid, ':dlugosc_trwania', $dlugosc_trwania);
    oci_execute($stid);

    oci_free_statement($stid);
    oci_close($conn);

    $_SESSION['message'] = 'Zajęcia zostały pomyślnie dodane!';
    header("Location: trainer_dashboard.php");
    exit();
}
?>
