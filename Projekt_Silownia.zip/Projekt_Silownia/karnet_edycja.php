<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['type'] != 'trainer') {
    header("Location: login.php");
    exit();
}

include 'connection.php';
$conn = getConnection();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_karnetu = $_POST['id_karnetu'];
    $nazwa_karnetu = $_POST['nazwa_karnetu'];
    $opis = $_POST['opis'];
    $cena = $_POST['cena'];
    $dlugosc_trwania = $_POST['dlugosc_trwania'];
    $typ = $_POST['typ'];

    $query = "UPDATE KARNETY SET NAZWA = :nazwa_karnetu, OPIS = :opis, CENA = :cena, DLUGOSC_TRWANIA = :dlugosc_trwania, TYP = :typ WHERE ID_KARNETU = :id_karnetu";

    $stid = oci_parse($conn, $query);
    oci_bind_by_name($stid, ':id_karnetu', $id_karnetu);
    oci_bind_by_name($stid, ':nazwa_karnetu', $nazwa_karnetu);
    oci_bind_by_name($stid, ':opis', $opis);
    oci_bind_by_name($stid, ':cena', $cena);
    oci_bind_by_name($stid, ':dlugosc_trwania', $dlugosc_trwania);
    oci_bind_by_name($stid, ':typ', $typ);
    
    oci_execute($stid);
    oci_commit($conn);
    oci_free_statement($stid);
    oci_close($conn);

    header("Location: trainer_dashboard.php");
    exit();
}
?>
